#include <stdio.h>
#include "./inc/btree.h"
#include <string.h>

void add(BTA*, char*, long);
void traverse(BTA*);
void rtraverse(BTA*);
void findPhone(BTA*, char*, int);
void findName(BTA*, long);
void delete(BTA*, char*);
void update(BTA*, char*, long);
void retrieving_error();
void rm_duplicate(BTA*);
void sortByPhone(BTA*);

int main()
{
	btinit();
	BTA *B = btopn("Book.txt", 0, FALSE);
	if (B == NULL)
	{
		B = btcrt("Book.txt", 0, FALSE);
		if (!B) return -1;
	}

	// btdups(B, FALSE); // duplicate TRUE | FALSE // ERROR

	// btthresh(B, 1000); // ??
	// btcrtr(B, "X"); // create a root ???
	// btchgr(B, "X"); // change root ???
	// btdelr(B, "X"); // delete root ???

	// Debug
	// bdbug(B, "control", ZNULL);
	// bdbug(B, "super", ZNULL);
	// bdbug(B, "stack", ZNULL);
	// bdbug(B, "space", ZNULL);
	// bdbug(B, "stats", ZNULL);
	// bdbug(B, "block", ZNULL);
	// bdbug(B, "structure", ZNULL);

	// add(B, "A", 1);
	// add(B, "B", 2);
	// add(B, "C", 3);
	// update(B, "B", 99);
	delete(B, "B");

	traverse(B);
	retrieving_error();
	btcls(B);
	return 0;
}

void add(BTA *Book, char* name, long number)
{
	btins(Book, name, (char*)&number, sizeof(number));
}

void traverse(BTA* Book) // duyet tu vi tri dau file
{
	if (btpos(Book, ZSTART))
		return;

	char name[100];
	long number;
	int size;

	while (!btseln(Book, name, (char*)&number, sizeof(number), &size))
		printf("%s - %ld\n", name, number);
}

void rtraverse(BTA* Book) // duyet tu vi tri cuoi file
{
	if (btpos(Book, ZEND))
		return;

	long number;
	int size;
	char name[100];

	while (!btselp(Book, name, (char*)&number, sizeof(number), &size))
		printf("%s - %ld\n", name, number);
}

void findPhone(BTA *Book, char *name, int dup) // if dulicated
{
	long number;
	int size;

	if(btsel(Book, name, (char*)&number, sizeof(number), &size))
	{
        printf("Not found %s\n", name);
		return;
	}
    printf("%s - %ld\n", name, number);

	if (dup)
	{
		char st[100];
		while (!btseln(Book, st, (char*)&number, sizeof(number), &size) && strcmp(st, name) == 0)
			printf("%s - %ld\n", st, number);
	}
}

void findName(BTA* Book, long phone_number)
{
	if (btpos(Book, ZSTART))
	{
		printf("Not found\n");
		return;
	}

	char name[100];
	long number;
	int size;

	while (!btseln(Book, name, (char*)&number, sizeof(number), &size))
		if (number == phone_number)
			printf("%s - %ld\n", name, number);
}

void delete(BTA *Book, char *name)
{
	btdel(Book, name);
}

void update(BTA *Book, char *name, long number)
{
	btupd(Book, name, (char*)&number, sizeof(number));
}

void retrieving_error()
{
	int err, ioerr;
	char st1[100], st2[100];
	btcerr(&err, &ioerr, st1, st2);
	printf("%d - %d - %s - %s\n", err, ioerr, st1, st2);
}

void rm_duplicate(BTA* Book)
{

}

void sortByPhone(BTA *Book)
{

}